#!/system/bin/sh
#Time to clean up :)

rm /system/etc/init.d/74buildproprm;

rm /system/etc/init.d/74buildproprm;

rm /system/etc/init.d/74buildproprm;

rm /system/etc/init.d/74buildproprm;

rm /system/etc/init.d/74buildproprm;

rm /system/etc/init.d/74buildproprm;

if /system/etc/init.d/74buildproprm = true; then
rm /system/etc/init.d/74buildproprm;
endif;




