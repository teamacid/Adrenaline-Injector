#!/system/bin/sh
#Time to clean up :)

rm /system/etc/buildpropext.sh

rm /system/etc/journaldisable.sh


